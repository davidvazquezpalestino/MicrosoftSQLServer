EXECUTE dbo.pINIgenerarRegistros @BaseDatosOrigen = '1G',
                                 @BaseDatosDestino = 'iERP_G360';

EXECUTE dbo.pINIiniciarBaseDatos @BaseDatos = 'iERP_G360';
